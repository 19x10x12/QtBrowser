@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ==================================================
echo   QtBrowser - Automatische Check en Bouwer
echo ==================================================
echo.

REM --- 1. Check & Installeer CMake ---
where cmake >nul 2>&1
if errorlevel 1 (
    echo [!] CMake niet gevonden. Bezig met automatisch downloaden en installeren...
    winget install --id Kitware.CMake -e --silent --accept-package-agreements --accept-source-agreements
    set "PATH=%PATH%;C:\Program Files\CMake\bin"
) else (
    echo [OK] CMake is al geinstalleerd.
)

REM --- 2. Check & Installeer Visual Studio 2022 Build Tools (C++) ---
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
set "VS_FOUND=0"
if exist "%VSWHERE%" (
    for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do (
        set "VS_FOUND=1"
    )
)
if "!VS_FOUND!"=="0" (
    echo [!] Visual Studio C++ compiler niet gevonden. Bezig met installeren...
    echo     Dit is een groot pakket en kan even duren...
    winget install --id Microsoft.VisualStudio.2022.BuildTools -e --silent --override "--wait --quiet --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended" --accept-package-agreements --accept-source-agreements
) else (
    echo [OK] Visual Studio C++ is al geinstalleerd.
)

REM --- 3. Zoek Qt 6 (of installeer automatisch via aqtinstall) ---
if "%QT_DIR%"=="" (
    for /d %%D in (C:\Qt\6.*) do (
        if exist "%%D\msvc2022_64\bin\windeployqt.exe" set "QT_DIR=%%D\msvc2022_64"
        if exist "%%D\msvc2019_64\bin\windeployqt.exe" set "QT_DIR=%%D\msvc2019_64"
    )
)

if not exist "%QT_DIR%\bin\windeployqt.exe" (
    echo [!] Qt 6 met WebEngine niet gevonden in C:\Qt.
    echo     Bezig met automatisch downloaden van Qt 6.8.1 via Python/aqtinstall...
    where python >nul 2>&1
    if errorlevel 1 (
        echo     Python wordt eerst geinstalleerd om Qt automatisch binnen te halen...
        winget install --id Python.Python.3.12 -e --silent --accept-package-agreements --accept-source-agreements
        set "PATH=%PATH%;%LocalAppData%\Programs\Python\Python312;%LocalAppData%\Programs\Python\Python312\Scripts"
    )
    python -m pip install --quiet aqtinstall
    python -m aqt install-qt windows desktop 6.8.1 win64_msvc2022_64 -m qtwebengine qtpositioning qtwebchannel -O C:\Qt
    set "QT_DIR=C:\Qt\6.8.1\msvc2022_64"
)

if not exist "%QT_DIR%\bin\windeployqt.exe" (
    echo.
    echo [FOUT] Het automatisch installeren van Qt is niet gelukt.
    pause
    exit /b 1
) else (
    echo [OK] Qt gevonden in: %QT_DIR%
)

echo.
echo [1/3] Project configureren...
cmake -S . -B build -G "Visual Studio 17 2022" -A x64 -DCMAKE_PREFIX_PATH="%QT_DIR%"
if errorlevel 1 ( pause & exit /b 1 )

echo [2/3] Browser compileren (dit duurt enkele minuten)...
cmake --build build --config Release
if errorlevel 1 ( pause & exit /b 1 )

echo [3/3] Qt en Chromium bestanden bundelen...
if exist dist\QtBrowser rmdir /S /Q dist\QtBrowser
mkdir dist\QtBrowser
copy /Y build\Release\QtBrowser.exe dist\QtBrowser\ >nul
"%QT_DIR%\bin\windeployqt.exe" --release --no-translations dist\QtBrowser\QtBrowser.exe
if errorlevel 1 ( pause & exit /b 1 )

echo.
echo ==================================================
echo   KLAAR! Start je browser via:
echo   dist\QtBrowser\QtBrowser.exe
echo ==================================================
pause
endlocal
