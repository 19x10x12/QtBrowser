@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ==================================================
echo   QtBrowser - Verwijderprogramma (Uninstaller)
echo ==================================================
echo.
echo Kies wat je wilt verwijderen:
echo   [1] Alleen de gebouwde browser (de mappen 'build' en 'dist')
echo   [2] ALLES: de browser + de extra gedownloade bouw-tools
echo       (Verwijdert C:\Qt, aqtinstall, CMake en VS Build Tools.
echo        Python zelf blijft gewoon behouden!)
echo   [3] Annuleren
echo.
set /p "KEUZE=Typ 1, 2 of 3 en druk op Enter: "

if "%KEUZE%"=="3" goto :EINDE
if not "%KEUZE%"=="1" if not "%KEUZE%"=="2" (
    echo Ongeldige keuze. Afgesloten.
    pause
    exit /b 1
)

echo.
echo [1/2] Eventueel geopende QtBrowser sluiten en mappen opruimen...
taskkill /F /IM QtBrowser.exe >nul 2>&1
if exist "build" (
    rmdir /S /Q "build"
    echo   - Map 'build' verwijderd.
)
if exist "dist" (
    rmdir /S /Q "dist"
    echo   - Map 'dist' verwijderd.
)

if "%KEUZE%"=="1" (
    echo.
    echo Klaar! Alleen de browserbestanden zijn verwijderd.
    goto :EINDE
)

echo.
echo [2/2] Extra gedownloade bouw-tools verwijderen (Python blijft staan)...

REM --- Verwijder de extra Python-library aqtinstall (niet Python zelf) ---
where python >nul 2>&1
if not errorlevel 1 (
    echo   - Python library 'aqtinstall' verwijderen...
    python -m pip uninstall -y aqtinstall >nul 2>&1
)

REM --- Verwijder de Qt-installatiemap C:\Qt ---
if exist "C:\Qt" (
    echo   - Map C:\Qt verwijderen (dit kan even duren)...
    rmdir /S /Q "C:\Qt"
)

REM --- Verwijder CMake via winget ---
echo   - CMake verwijderen...
winget uninstall --id Kitware.CMake -e --silent --accept-source-agreements >nul 2>&1

REM --- Verwijder Visual Studio 2022 Build Tools via winget ---
echo   - Visual Studio 2022 Build Tools verwijderen (dit duurt enkele minuten)...
winget uninstall --id Microsoft.VisualStudio.2022.BuildTools -e --silent --accept-source-agreements >nul 2>&1

echo.
echo ==================================================
echo   KLAAR! De browser en extra tools zijn verwijderd.
echo   Python is gewoon op je computer blijven staan.
echo ==================================================

:EINDE
pause
endlocal
