cmake_minimum_required(VERSION 3.21)
project(QtBrowser LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_AUTOMOC ON)

# Qt 6 with the WebEngine module (Chromium). Pass -DCMAKE_PREFIX_PATH=<Qt dir>.
find_package(Qt6 REQUIRED COMPONENTS Widgets Network WebEngineWidgets)

# WIN32 = GUI subsystem (no console window).
qt_add_executable(QtBrowser WIN32 main.cpp)
target_link_libraries(QtBrowser PRIVATE Qt6::Widgets Qt6::Network Qt6::WebEngineWidgets)
if(MSVC)
  target_compile_options(QtBrowser PRIVATE /utf-8 /W3)
endif()
