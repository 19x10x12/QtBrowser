// QtBrowser - a native C++ desktop web browser built on Qt 6 + QtWebEngine (Chromium).
//
// Features: tabs, omnibox (URL/search detection), back/forward/reload/home,
// bookmarks, network-layer ad/tracker blocker, first-run setup wizard,
// settings dialog, downloads, fullscreen video.
//
// User data lives in ~/.pybrowser (same folder/format as the Python version):
// settings.json, bookmarks.json, blocklist.txt, plus the Chromium profile.

#include <QApplication>
#include <QAction>
#include <QCheckBox>
#include <QDialog>
#include <QDir>
#include <QEventLoop>
#include <QFile>
#include <QFileDialog>
#include <QHBoxLayout>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLabel>
#include <QLineEdit>
#include <QMainWindow>
#include <QMenu>
#include <QMessageBox>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QPushButton>
#include <QRadioButton>
#include <QReadWriteLock>
#include <QRegularExpression>
#include <QSet>
#include <QShortcut>
#include <QTabBar>
#include <QTabWidget>
#include <QTimer>
#include <QToolBar>
#include <QToolButton>
#include <QVBoxLayout>
#include <QWebEngineDownloadRequest>
#include <QWebEngineFullScreenRequest>
#include <QWebEnginePage>
#include <QWebEngineProfile>
#include <QWebEngineSettings>
#include <QWebEngineUrlRequestInfo>
#include <QWebEngineUrlRequestInterceptor>
#include <QWebEngineView>
#include <atomic>

// --------------------------------------------------------------------------
// Storage helpers
// --------------------------------------------------------------------------
static QString dataDir() {
    QString d = QDir::homePath() + "/.pybrowser";
    QDir().mkpath(d);
    return d;
}
static QString settingsPath()  { return dataDir() + "/settings.json"; }
static QString bookmarksPath() { return dataDir() + "/bookmarks.json"; }
static QString blocklistPath() { return dataDir() + "/blocklist.txt"; }

static QJsonDocument loadJson(const QString& path) {
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly)) return {};
    return QJsonDocument::fromJson(f.readAll());
}
static void saveJson(const QString& path, const QJsonDocument& doc) {
    QFile f(path);
    if (f.open(QIODevice::WriteOnly | QIODevice::Truncate)) f.write(doc.toJson());
}

// "%s" in the template is replaced by the URL-encoded query.
static const QList<QPair<QString, QString>> kEngines = {
    {"Google",       "https://www.google.com/search?q=%s"},
    {"DuckDuckGo",   "https://duckduckgo.com/?q=%s"},
    {"Bing",         "https://www.bing.com/search?q=%s"},
    {"Brave Search", "https://search.brave.com/search?q=%s"},
    {"Ecosia",       "https://www.ecosia.org/search?q=%s"},
};
static const char* kBlocklistUrl =
    "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=nohtml&showintro=0";

// --------------------------------------------------------------------------
// Ad / tracker blocker: runs for every network request (on Chromium's IO thread)
// --------------------------------------------------------------------------
class AdBlocker : public QWebEngineUrlRequestInterceptor {
public:
    std::atomic<bool> enabled{true};
    std::atomic<int> blocked{0};

    explicit AdBlocker(QObject* parent = nullptr) : QWebEngineUrlRequestInterceptor(parent) {
        reloadExtra();
    }

    // Built-in list + optional downloaded list (hosts format or one domain per line).
    void reloadExtra() {
        static const char* builtin[] = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "google-analytics.com", "googletagmanager.com",
            "googletagservices.com", "adnxs.com", "adsrvr.org", "advertising.com",
            "adform.net", "amazon-adsystem.com", "criteo.com", "criteo.net",
            "taboola.com", "outbrain.com", "rubiconproject.com", "pubmatic.com",
            "openx.net", "casalemedia.com", "indexww.com", "smartadserver.com",
            "moatads.com", "scorecardresearch.com", "quantserve.com", "quantcount.com",
            "adsafeprotected.com", "serving-sys.com", "2mdn.net", "yieldmo.com",
            "media.net", "zedo.com", "revcontent.com", "mgid.com", "sharethrough.com",
            "teads.tv", "bidswitch.net", "contextweb.com", "lijit.com", "33across.com",
            "hotjar.com", "mixpanel.com", "segment.io", "crazyegg.com", "mouseflow.com",
            "fullstory.com", "adcolony.com", "chartbeat.net", "facebook.net",
            "ads.twitter.com", "analytics.twitter.com", "ads.linkedin.com",
            "ads.pinterest.com", "ads.yahoo.com", "analytics.yahoo.com", "bat.bing.com",
            "popads.net", "propellerads.com", "exoclick.com", "juicyads.com",
            "adsterra.com"};
        QSet<QString> d;
        for (const char* s : builtin) d.insert(QString::fromLatin1(s));
        QFile f(blocklistPath());
        if (f.open(QIODevice::ReadOnly | QIODevice::Text)) {
            while (!f.atEnd()) {
                QString line = QString::fromUtf8(f.readLine());
                line = line.left(line.indexOf('#') < 0 ? line.size() : line.indexOf('#')).trimmed();
                if (line.isEmpty()) continue;
                QString dom = line.split(QRegularExpression("\\s+")).last().toLower();
                if (dom.contains('.')) d.insert(dom);
            }
        }
        QWriteLocker lock(&lock_);
        domains_ = d;
    }

    void interceptRequest(QWebEngineUrlRequestInfo& info) override {
        if (!enabled) return;
        // Never block the page the user is navigating to.
        if (info.resourceType() == QWebEngineUrlRequestInfo::ResourceTypeMainFrame) return;
        if (isBlockedHost(info.requestUrl().host().toLower())) {
            info.block(true);
            ++blocked;
        }
    }

private:
    bool isBlockedHost(const QString& host) {
        const QStringList parts = host.split('.');
        QReadLocker lock(&lock_);
        // Check "a.b.c.com", "b.c.com", "c.com" (never a bare TLD).
        for (int i = 0; i < parts.size() - 1; ++i)
            if (domains_.contains(parts.mid(i).join('.'))) return true;
        return false;
    }
    QReadWriteLock lock_;
    QSet<QString> domains_;
};

static bool downloadBlocklist(QString& err) {
    QNetworkAccessManager nam;
    QNetworkRequest req{QUrl(kBlocklistUrl)};
    req.setAttribute(QNetworkRequest::RedirectPolicyAttribute, QNetworkRequest::NoLessSafeRedirectPolicy);
    QNetworkReply* r = nam.get(req);
    QEventLoop loop;
    QObject::connect(r, &QNetworkReply::finished, &loop, &QEventLoop::quit);
    QTimer::singleShot(15000, &loop, &QEventLoop::quit);
    loop.exec();
    if (!r->isFinished()) { err = "Timed out"; r->abort(); r->deleteLater(); return false; }
    if (r->error() != QNetworkReply::NoError) { err = r->errorString(); r->deleteLater(); return false; }
    QFile f(blocklistPath());
    bool ok = f.open(QIODevice::WriteOnly | QIODevice::Truncate) && f.write(r->readAll()) >= 0;
    if (!ok) err = "Could not write blocklist file";
    r->deleteLater();
    return ok;
}

// --------------------------------------------------------------------------
// Omnibox: decide between URL and search query
// --------------------------------------------------------------------------
static QUrl resolveInput(const QString& input, const QString& tmpl) {
    const QString t = input.trimmed();
    if (t.isEmpty()) return QUrl("about:blank");
    static const QRegularExpression scheme("^[a-zA-Z][a-zA-Z0-9+.-]*://");
    static const QRegularExpression host(
        R"(^(localhost|(\d{1,3}\.){3}\d{1,3}|([\w-]+\.)+[a-zA-Z]{2,})(:\d+)?(/.*)?$)");
    if (scheme.match(t).hasMatch() || t.startsWith("about:") || t.startsWith("file:"))
        return QUrl(t);
    if (!t.contains(' ') && host.match(t).hasMatch()) return QUrl("https://" + t);
    QString url = tmpl;
    url.replace("%s", QString::fromUtf8(QUrl::toPercentEncoding(t)));
    return QUrl(url);
}

// --------------------------------------------------------------------------
// Setup wizard / settings dialog (one widget, two modes)
// --------------------------------------------------------------------------
class SetupDialog : public QDialog {
public:
    bool blocklistUpdated = false;

    SetupDialog(const QJsonObject& s, bool firstRun, QWidget* parent = nullptr) : QDialog(parent) {
        setWindowTitle(firstRun ? "Welcome to QtBrowser" : "Settings");
        setMinimumWidth(460);
        auto* layout = new QVBoxLayout(this);

        if (firstRun) {
            auto* title = new QLabel(
                "<h2>Welcome to QtBrowser 👋</h2><p>Let's finish a quick setup. "
                "You can change everything later in Settings.</p>");
            title->setWordWrap(true);
            layout->addWidget(title);
        }

        layout->addWidget(new QLabel("<b>Default search engine</b>"));
        const QString current = s.value("search_engine").toString("DuckDuckGo");
        for (const auto& e : kEngines) {
            auto* rb = new QRadioButton(e.first);
            rb->setChecked(e.first == current);
            radios_.append(rb);
            layout->addWidget(rb);
        }
        custom_ = new QRadioButton("Custom search URL");
        custom_->setChecked(current == "Custom");
        layout->addWidget(custom_);
        customEdit_ = new QLineEdit(s.value("custom_url").toString());
        customEdit_->setPlaceholderText("https://example.com/search?q=%s   (%s = your query)");
        layout->addWidget(customEdit_);

        adblock_ = new QCheckBox("Enable ad && tracker blocker");
        adblock_->setChecked(s.value("adblock").toBool(true));
        layout->addWidget(adblock_);

        if (!firstRun) {
            auto* upd = new QPushButton("Update blocklist (download extended list)");
            connect(upd, &QPushButton::clicked, this, [this] {
                QApplication::setOverrideCursor(Qt::WaitCursor);
                QString err;
                bool ok = downloadBlocklist(err);
                QApplication::restoreOverrideCursor();
                if (ok) { blocklistUpdated = true; QMessageBox::information(this, "Blocklist", "Blocklist updated successfully."); }
                else QMessageBox::warning(this, "Blocklist", "Download failed:\n" + err);
            });
            layout->addWidget(upd);
        }

        auto* row = new QHBoxLayout;
        row->addStretch();
        auto* ok = new QPushButton(firstRun ? "Get started" : "Save");
        ok->setDefault(true);
        connect(ok, &QPushButton::clicked, this, [this] {
            if (custom_->isChecked() && !customEdit_->text().contains("%s")) {
                QMessageBox::warning(this, "Custom search URL",
                    "The custom URL must contain %s where the query goes.\n"
                    "Example: https://example.com/search?q=%s");
                return;
            }
            accept();
        });
        row->addWidget(ok);
        if (!firstRun) {
            auto* cancel = new QPushButton("Cancel");
            connect(cancel, &QPushButton::clicked, this, &QDialog::reject);
            row->addWidget(cancel);
        }
        layout->addLayout(row);
    }

    QJsonObject values() const {
        QString engine = "Custom";
        for (auto* rb : radios_) if (rb->isChecked()) engine = rb->text();
        return {{"search_engine", engine},
                {"custom_url", customEdit_->text().trimmed()},
                {"adblock", adblock_->isChecked()}};
    }

private:
    QList<QRadioButton*> radios_;
    QRadioButton* custom_;
    QLineEdit* customEdit_;
    QCheckBox* adblock_;
};

// --------------------------------------------------------------------------
// Web view (opens target=_blank / window.open in new tabs) and main window
// --------------------------------------------------------------------------
class Browser;

class WebView : public QWebEngineView {
public:
    WebView(Browser* b, QWebEngineProfile* profile) : browser_(b) {
        setPage(new QWebEnginePage(profile, this));
    }
protected:
    QWebEngineView* createWindow(QWebEnginePage::WebWindowType) override;
private:
    Browser* browser_;
};

class Browser : public QMainWindow {
public:
    explicit Browser(const QJsonObject& settings) : settings_(settings) {
        bookmarks_ = loadJson(bookmarksPath()).array();
        resize(1280, 820);
        setWindowTitle("QtBrowser");

        // Persistent Chromium profile: cookies, localStorage, cache survive restarts.
        blocker_ = new AdBlocker;
        blocker_->enabled = settings_.value("adblock").toBool(true);
        profile_ = new QWebEngineProfile("QtBrowserProfile");
        profile_->setPersistentStoragePath(dataDir() + "/profile");
        profile_->setCachePath(dataDir() + "/cache");
        profile_->setPersistentCookiesPolicy(QWebEngineProfile::ForcePersistentCookies);
        profile_->setUrlRequestInterceptor(blocker_);
        QWebEngineSettings* ws = profile_->settings();
        ws->setAttribute(QWebEngineSettings::FullScreenSupportEnabled, true);
        ws->setAttribute(QWebEngineSettings::PluginsEnabled, true);
        ws->setAttribute(QWebEngineSettings::JavascriptEnabled, true);
        ws->setAttribute(QWebEngineSettings::LocalStorageEnabled, true);
        ws->setAttribute(QWebEngineSettings::ScrollAnimatorEnabled, true);

        connect(profile_, &QWebEngineProfile::downloadRequested, this, [this](QWebEngineDownloadRequest* item) {
            QString path = QFileDialog::getSaveFileName(
                this, "Save file", QDir::homePath() + "/Downloads/" + item->downloadFileName());
            if (path.isEmpty()) { item->cancel(); return; }
            QFileInfo fi(path);
            item->setDownloadDirectory(fi.absolutePath());
            item->setDownloadFileName(fi.fileName());
            item->accept();
        });

        buildUi();
        addTab();

        auto* timer = new QTimer(this);
        connect(timer, &QTimer::timeout, this, [this] { refreshAdblockButton(); });
        timer->start(1000);
    }

    ~Browser() override {
        // Pages must be destroyed before the profile; the profile before the interceptor.
        while (tabs_->count() > 0) {
            QWidget* w = tabs_->widget(0);
            tabs_->removeTab(0);
            delete w;
        }
        delete profile_;
        delete blocker_;
    }

    WebView* addTab(const QUrl& url = QUrl(), bool loadHome = true) {
        auto* view = new WebView(this, profile_);
        int idx = tabs_->addTab(view, "New Tab");
        connect(view, &QWebEngineView::titleChanged, this, [this, view](const QString& t) {
            int i = tabs_->indexOf(view);
            if (i < 0) return;
            tabs_->setTabText(i, t.size() > 25 ? t.left(24) + "…" : t);
            tabs_->setTabToolTip(i, t);
            if (view == cur()) setWindowTitle(t + " - QtBrowser");
        });
        connect(view, &QWebEngineView::iconChanged, this, [this, view](const QIcon& ic) {
            tabs_->setTabIcon(tabs_->indexOf(view), ic);
        });
        connect(view, &QWebEngineView::urlChanged, this, [this, view](const QUrl& u) {
            if (view == cur()) updateOmnibox(u);
        });
        connect(view, &QWebEngineView::loadStarted, this, [this, view] {
            if (view == cur()) reloadAct_->setText("✕");
        });
        connect(view, &QWebEngineView::loadFinished, this, [this, view](bool) {
            if (view == cur()) reloadAct_->setText("⟳");
        });
        connect(view->page(), &QWebEnginePage::fullScreenRequested, this,
                [this](QWebEngineFullScreenRequest req) {
            req.accept();
            bool on = req.toggleOn();
            toolbar_->setVisible(!on);
            tabs_->tabBar()->setVisible(!on);
            if (on) showFullScreen(); else showNormal();
        });
        tabs_->setCurrentIndex(idx);
        if (!url.isEmpty()) view->setUrl(url);
        else if (loadHome) view->setUrl(homeUrl());
        return view;
    }

private:
    WebView* cur() const { return static_cast<WebView*>(tabs_->currentWidget()); }

    QString searchTemplate() const {
        QString name = settings_.value("search_engine").toString("DuckDuckGo");
        for (const auto& e : kEngines) if (e.first == name) return e.second;
        QString custom = settings_.value("custom_url").toString();
        return custom.isEmpty() ? kEngines[1].second : custom;
    }
    QUrl homeUrl() const {
        QUrl u(searchTemplate());
        return QUrl(u.scheme() + "://" + u.authority() + "/");
    }

    void buildUi() {
        tabs_ = new QTabWidget;
        tabs_->setDocumentMode(true);
        tabs_->setTabsClosable(true);
        tabs_->setMovable(true);
        connect(tabs_, &QTabWidget::tabCloseRequested, this, [this](int i) { closeTab(i); });
        connect(tabs_, &QTabWidget::currentChanged, this, [this](int) {
            if (auto* v = cur()) {
                updateOmnibox(v->url());
                setWindowTitle((v->title().isEmpty() ? "New Tab" : v->title()) + " - QtBrowser");
            }
        });
        auto* plus = new QToolButton;
        plus->setText("＋");
        plus->setToolTip("New tab (Ctrl+T)");
        connect(plus, &QToolButton::clicked, this, [this] { addTab(); });
        tabs_->setCornerWidget(plus, Qt::TopRightCorner);
        setCentralWidget(tabs_);

        toolbar_ = new QToolBar("Navigation");
        toolbar_->setMovable(false);
        addToolBar(toolbar_);

        auto act = [this](const QString& text, const QString& tip, std::function<void()> fn) {
            QAction* a = toolbar_->addAction(text);
            a->setToolTip(tip);
            connect(a, &QAction::triggered, this, [fn] { fn(); });
            return a;
        };
        act("◀", "Back (Alt+Left)", [this] { if (cur()) cur()->back(); });
        act("▶", "Forward (Alt+Right)", [this] { if (cur()) cur()->forward(); });
        reloadAct_ = act("⟳", "Reload (F5)", [this] { reloadOrStop(); });
        act("⌂", "Home", [this] { navigate(homeUrl().toString()); });

        omnibox_ = new QLineEdit;
        omnibox_->setPlaceholderText("Search or enter address");
        omnibox_->setClearButtonEnabled(true);
        connect(omnibox_, &QLineEdit::returnPressed, this, [this] { navigate(omnibox_->text()); });
        toolbar_->addWidget(omnibox_);

        starAct_ = act("☆", "Bookmark this page (Ctrl+D)", [this] { toggleBookmark(); });

        bmMenu_ = new QMenu(this);
        connect(bmMenu_, &QMenu::aboutToShow, this, [this] { rebuildBookmarksMenu(); });
        auto* bmBtn = new QToolButton;
        bmBtn->setText("🔖");
        bmBtn->setToolTip("Bookmarks");
        bmBtn->setMenu(bmMenu_);
        bmBtn->setPopupMode(QToolButton::InstantPopup);
        toolbar_->addWidget(bmBtn);

        // The ad blocker button is both the toggle and the status indicator.
        adblockBtn_ = new QToolButton;
        adblockBtn_->setCheckable(true);
        connect(adblockBtn_, &QToolButton::toggled, this, [this](bool on) {
            blocker_->enabled = on;
            settings_["adblock"] = on;
            saveJson(settingsPath(), QJsonDocument(settings_));
            refreshAdblockButton();
            if (cur()) cur()->reload();  // apply to the current page immediately
        });
        toolbar_->addWidget(adblockBtn_);
        refreshAdblockButton();

        act("⚙", "Settings", [this] { openSettings(); });

        auto shortcut = [this](const char* seq, std::function<void()> fn) {
            auto* sc = new QShortcut(QKeySequence(seq), this);
            connect(sc, &QShortcut::activated, this, [fn] { fn(); });
        };
        shortcut("Ctrl+T", [this] { addTab(); });
        shortcut("Ctrl+W", [this] { closeTab(tabs_->currentIndex()); });
        shortcut("Ctrl+L", [this] { omnibox_->setFocus(); omnibox_->selectAll(); });
        shortcut("Ctrl+D", [this] { toggleBookmark(); });
        shortcut("F5", [this] { reloadOrStop(); });
        shortcut("Alt+Left", [this] { if (cur()) cur()->back(); });
        shortcut("Alt+Right", [this] { if (cur()) cur()->forward(); });
    }

    void closeTab(int i) {
        if (tabs_->count() <= 1) { close(); return; }
        QWidget* w = tabs_->widget(i);
        tabs_->removeTab(i);
        w->deleteLater();
    }

    void navigate(const QString& text) {
        if (cur()) cur()->setUrl(resolveInput(text, searchTemplate()));
    }
    void reloadOrStop() {
        if (!cur()) return;
        if (reloadAct_->text() == "✕") cur()->stop(); else cur()->reload();
    }
    void updateOmnibox(const QUrl& url) {
        QString t = url.toString();
        omnibox_->setText(t == "about:blank" ? QString() : t);
        omnibox_->setCursorPosition(0);
        starAct_->setText(isBookmarked(t) ? "★" : "☆");
    }

    // ---- bookmarks ----
    bool isBookmarked(const QString& url) const {
        for (const auto& b : bookmarks_) if (b.toObject().value("url").toString() == url) return true;
        return false;
    }
    void removeBookmark(const QString& url) {
        QJsonArray out;
        for (const auto& b : bookmarks_) if (b.toObject().value("url").toString() != url) out.append(b);
        bookmarks_ = out;
        saveJson(bookmarksPath(), QJsonDocument(bookmarks_));
    }
    void toggleBookmark() {
        if (!cur()) return;
        QString url = cur()->url().toString();
        if (isBookmarked(url)) removeBookmark(url);
        else {
            bookmarks_.append(QJsonObject{{"title", cur()->title().isEmpty() ? url : cur()->title()}, {"url", url}});
            saveJson(bookmarksPath(), QJsonDocument(bookmarks_));
        }
        updateOmnibox(cur()->url());
    }
    void rebuildBookmarksMenu() {
        bmMenu_->clear();
        auto add = [this](QMenu* m, const QString& text, std::function<void()> fn) {
            QAction* a = m->addAction(text);
            connect(a, &QAction::triggered, this, [fn] { fn(); });
        };
        add(bmMenu_, "Bookmark this page (Ctrl+D)", [this] { toggleBookmark(); });
        bmMenu_->addSeparator();
        if (bookmarks_.isEmpty()) bmMenu_->addAction("(no bookmarks yet)")->setEnabled(false);
        for (const auto& b : bookmarks_) {
            QString url = b.toObject().value("url").toString();
            add(bmMenu_, b.toObject().value("title").toString().left(50), [this, url] { navigate(url); });
        }
        if (!bookmarks_.isEmpty()) {
            bmMenu_->addSeparator();
            QMenu* rm = bmMenu_->addMenu("Remove bookmark");
            for (const auto& b : bookmarks_) {
                QString url = b.toObject().value("url").toString();
                add(rm, b.toObject().value("title").toString().left(50), [this, url] {
                    removeBookmark(url);
                    if (cur()) updateOmnibox(cur()->url());
                });
            }
        }
    }

    // ---- ad blocker indicator & settings ----
    void refreshAdblockButton() {
        bool on = blocker_->enabled;
        adblockBtn_->blockSignals(true);
        adblockBtn_->setChecked(on);
        adblockBtn_->blockSignals(false);
        if (on) {
            adblockBtn_->setText(QString("🛡 ON · %1").arg(blocker_->blocked.load()));
            adblockBtn_->setStyleSheet("color: #1a8f3c; font-weight: bold;");
            adblockBtn_->setToolTip(QString("Ad blocker ON - %1 requests blocked. Click to disable.")
                                        .arg(blocker_->blocked.load()));
        } else {
            adblockBtn_->setText("🛡 OFF");
            adblockBtn_->setStyleSheet("color: #b00020;");
            adblockBtn_->setToolTip("Ad blocker OFF. Click to enable.");
        }
    }
    void openSettings() {
        SetupDialog dlg(settings_, false, this);
        bool accepted = dlg.exec() == QDialog::Accepted;
        if (dlg.blocklistUpdated) blocker_->reloadExtra();
        if (accepted) {
            QJsonObject v = dlg.values();
            for (auto it = v.begin(); it != v.end(); ++it) settings_[it.key()] = it.value();
            saveJson(settingsPath(), QJsonDocument(settings_));
            blocker_->enabled = settings_.value("adblock").toBool(true);
            refreshAdblockButton();
        }
    }

    QJsonObject settings_;
    QJsonArray bookmarks_;
    AdBlocker* blocker_ = nullptr;
    QWebEngineProfile* profile_ = nullptr;
    QTabWidget* tabs_ = nullptr;
    QToolBar* toolbar_ = nullptr;
    QLineEdit* omnibox_ = nullptr;
    QAction* reloadAct_ = nullptr;
    QAction* starAct_ = nullptr;
    QMenu* bmMenu_ = nullptr;
    QToolButton* adblockBtn_ = nullptr;
};

QWebEngineView* WebView::createWindow(QWebEnginePage::WebWindowType) {
    return browser_->addTab(QUrl(), false);
}

// --------------------------------------------------------------------------
int main(int argc, char* argv[]) {
    qputenv("QTWEBENGINE_CHROMIUM_FLAGS", "--ignore-gpu-blocklist");
    QApplication app(argc, argv);
    app.setApplicationName("QtBrowser");

    QJsonObject settings = loadJson(settingsPath()).object();
    if (!settings.contains("search_engine")) {  // first launch -> setup wizard
        SetupDialog dlg(QJsonObject(), true);
        if (dlg.exec() == QDialog::Accepted) settings = dlg.values();
        else settings = {{"search_engine", "DuckDuckGo"}, {"custom_url", ""}, {"adblock", true}};
        saveJson(settingsPath(), QJsonDocument(settings));
    }

    Browser window(settings);
    window.show();
    return app.exec();
}
